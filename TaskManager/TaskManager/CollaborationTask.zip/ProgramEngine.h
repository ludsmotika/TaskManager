#pragma once
#include "Session.h"

class ProgramEngine 
{
public:
	static void run(Session& session);
private:
};